# Design Patterns: IoC and DI

IoC: Inversion of control

DI: Dependency inject

# Dependenncy Injection

RenderCallout NYI

**Reflection**

[https://docs.microsoft.com/en-us/dotnet/framework/reflection-and-codedom/reflection](https://docs.microsoft.com/en-us/dotnet/framework/reflection-and-codedom/reflection)

## Reference

- [https://docs.microsoft.com/en-us/aspnet/mvc/overview/older-versions/hands-on-labs/aspnet-mvc-4-dependency-injection](https://docs.microsoft.com/en-us/aspnet/mvc/overview/older-versions/hands-on-labs/aspnet-mvc-4-dependency-injection)
- [https://nearsoft.com/blog/writing-a-minimal-ioc-container-in-c/](https://nearsoft.com/blog/writing-a-minimal-ioc-container-in-c/)